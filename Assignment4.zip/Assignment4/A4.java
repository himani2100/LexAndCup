import java.io.*;
public class A4
{
static BufferedReader $br;
static BufferedWriter $bw;
public static void main (String[] args) throws Exception{
 int X;

X= 3;
if( X == 3)
{
 int Y;

} else {
 String y= "test";

}
$bw = new BufferedWriter(new FileWriter("XKOUTPUT"));
$bw.write(""+ (X+100));
$bw.close();



}

}