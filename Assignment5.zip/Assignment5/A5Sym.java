public class A5Sym
{
   public static final int QUOTATIONS   =  1;
   public static final int INT  =  2;
   public static final int REAL  =  3;
   public static final int STRING   =  4;
   public static final int WRITE    =   5;
   public static final int RETURN   = 6;
   public static final int READ  = 7;
   public static final int MAIN  = 8;
   public static final int IF    = 9;
   public static final int ELSE  = 10;
   public static final int END = 11;
   public static final int BEGIN = 12;

   public static final int ID = 13;
   public static final int NUMBER = 14;

   public static final int LEBRAC = 15;
   public static final int RIGBRAC = 16;
   public static final int SCOLON = 17;
   public static final int COMMA = 18;

   public static final int ERROR = 19;

   public static final int PLUS = 20;
   public static final int MINUS = 21;
   public static final int DIVIDE = 22;
   public static final int MULT = 23;
   public static final int NOTEQUAL = 24;
   public static final int EQUAL = 25;
   public static final int COLEQUAL = 26;
   public static final int EOF = 27;

}
