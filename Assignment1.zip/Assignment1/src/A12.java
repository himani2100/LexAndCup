import java.io.*;
import java.util.HashSet;
public class A12
{
	public static void main(String[] args) throws IOException
	{
		String line;
		boolean temp = false;

		HashSet<String> id = new HashSet<String>();

		try
		{
			BufferedReader buffer = new BufferedReader(new FileReader(args[0]));

			BufferedWriter writer = new BufferedWriter(new FileWriter("A1.output"));
			String some = "";

			while((line = buffer.readLine()) != null)
			{
				some += line + " ";
			}

			String[] tokens = some.split("WRITE|READ|IF|ELSE|RETURN|BEGIN|END|MAIN|STRING|INT|REAL|\"[^\"]*\"|\\W|_|\\s|\\d+[a-zA-Z]\"");

			for (String _2 : tokens)
			{
				if (_2.equals(""))
				{
					continue;
				}

				id.add(_2);
			}
			writer.write("Identifiers:"+ id.size());
			buffer.close();
			writer.close();
			}

		catch (FileNotFoundException ex)
		{
		};
	}
}
