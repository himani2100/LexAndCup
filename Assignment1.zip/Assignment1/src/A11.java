import java.io.*;
import java.util.*;
public class A11
{
	public static void main(String[] args) throws IOException
	{
		String line;
		String temp;
		HashSet<String> id = new HashSet<String>();
		StringTokenizer strtok;
		try
		{
			BufferedReader buffer = new BufferedReader(new FileReader(args[0]));
			BufferedWriter writer = new BufferedWriter(new FileWriter("A1.output"));
			while((line = buffer.readLine()) != null)
			{
				strtok = new StringTokenizer(line, " ;(),+/*-@#$%:=!&{}[]\\?^<>~`_");
				while(strtok.hasMoreTokens())
				{
					temp = strtok.nextToken();
					if(Character.isAlphabetic(temp.charAt(0)))
					{
						for(int character=0;character<temp.length();character++){
							if(temp.charAt(character)=='\"'){
								break;
							}else if(character==temp.length()-1)
							{
								id.add(temp);
							}else{
								continue;
							}
						}

					}
				}
			}
			for (String _9 : new String[]
			{
				"WRITE", "READ", "IF", "ELSE", "RETURN",
				"BEGIN", "END", "MAIN", "STRING", "INT", "REAL"
			})
			{
				id.remove(_9);
			}

			writer.write("Identifiers:"+ id.size());
			writer.close();
			buffer.close();
		}
		catch (FileNotFoundException ex)
		{
		};
	}
}
